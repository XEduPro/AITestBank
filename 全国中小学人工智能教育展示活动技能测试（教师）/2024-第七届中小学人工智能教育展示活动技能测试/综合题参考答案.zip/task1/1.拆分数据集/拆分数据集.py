# 拆分
from BaseDT.dataset import split_tab_dataset
path = "./auto-mpg.csv"
tx,ty,val_x,val_y = split_tab_dataset(path,data_column=range(0,7),label_column=7,train_val_ratio=0.8)