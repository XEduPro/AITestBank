import PySimpleGUI as sg
from XEdu.hub import Workflow as wf
from BaseDT.dataset import split_tab_dataset
import numpy as np

# 加载数据集和模型
path = "auto-mpg.csv"
tx, ty, val_x, val_y, scaler = split_tab_dataset(path, data_column=range(0, 7), label_column=7, normalize=True)
baseml = wf(task='baseml', checkpoint='baseml3.pkl')

# 定义GUI布局
layout = [
    [sg.Text("汽车燃油效率预测小应用")],
    [sg.Text("输入一个以逗号分隔的列表:\n（示例：8, 307, 130, 3504, 12, 70, 1）\n【输入数据需与数据集样式一致】", size=(50, 3))],
    [sg.InputText(key='list_input', size=(80, 1))],
    [sg.Button("预测"), sg.Button("退出")],
    [sg.Text("", size=(80, 1), key='output')]
]

# 创建窗口
window = sg.Window("燃油效率预测", layout)

while True:
    event, values = window.read()

    if event in (sg.WIN_CLOSED, "退出"):
        break

    if event == "预测":
        try:
            # 将输入的字符串转换为列表
            list_input = values['list_input']
            data = [float(x.strip()) for x in list_input.split(',')]

            # 检查数据长度是否正确
            if len(data) != 7:
                window['output'].update("请输入包含 7 个特征值的列表。")
                continue

            # 转换数据格式
            data = scaler.transform(np.array(data).reshape(1, -1))

            # 模型推理
            result = baseml.inference(data=data)
            mpg = result[0]

            # 输出预测结果
            window['output'].update(f'根据模型预测，你的汽车每加仑燃油可以行驶的英里数大约为：{mpg:.2f}英里每加仑')

        except Exception as e:
            window['output'].update(f"发生错误: {e}")

window.close()
