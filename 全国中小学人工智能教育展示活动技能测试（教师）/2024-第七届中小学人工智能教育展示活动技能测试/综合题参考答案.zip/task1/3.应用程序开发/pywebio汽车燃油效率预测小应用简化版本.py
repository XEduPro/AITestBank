from pywebio.input import *
from pywebio.output import *
from pywebio import start_server
from XEdu.hub import Workflow as wf

def main():
    # 实例化模型并指定pkl模型
    baseml = wf(task='baseml', checkpoint='mymodel.pkl')

    # 使用 input_group 来同时收集多个输入，需调整为自己需要的输入
    inputs = input_group("汽车燃油效率预测小应用", [
        textarea("输入一个以逗号分隔的列表", name='list_input', placeholder="例如：8, 307, 130, 3504, 12, 70, 1【输入数据需与模型训练时的数据一致】")
    ])
    
    try:
        # 将输入的字符串转换为列表
        list_input = inputs['list_input']
        data = [float(x.strip()) for x in list_input.split(',')]
        
        # 检查数据长度是否正确
        if len(data) != 7:
            put_text("请输入包含 7 个特征值的列表。")
            return

        # 调试信息
        print("输入的数据:", data)

        # 模型推理
        result = baseml.inference(data=[data])
        mpg = result[0]
        
        # 输出预测结果
        put_text(f'根据模型预测，你的汽车每加仑燃油可以行驶的英里数大约为：{mpg:.2f}英里每加仑')
    
    except Exception as e:
        put_text(f"发生错误: {e}")

if __name__ == '__main__':
    start_server(main, port=8080)
