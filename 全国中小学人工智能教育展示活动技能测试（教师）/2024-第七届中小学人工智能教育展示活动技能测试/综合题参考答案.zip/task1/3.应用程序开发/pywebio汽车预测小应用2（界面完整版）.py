from pywebio.input import *
from pywebio.output import *
from pywebio import start_server
from XEdu.hub import Workflow as wf
from BaseDT.dataset import split_tab_dataset
import numpy as np

def main():
    path = "auto-mpg.csv"
    tx, ty, val_x, val_y, scaler = split_tab_dataset(path, data_column=range(0, 7), label_column=7, normalize=True)  # 获取scaler

    # 实例化模型并指定pkl模型
    baseml = wf(task='baseml', checkpoint='baseml3.pkl')

    # 使用 input_group 来同时收集多个输入，需调整为自己需要的输入
    inputs = input_group("汽车燃油效率预测系统", [
        input("汽车发动机的气缸数量", name='cylinders', type=FLOAT, placeholder="例如：8"),
        input("发动机排量", name='displacement', type=FLOAT, placeholder="例如：307"),
        input("发动机的输出功率", name='horsepower', type=FLOAT,placeholder="例如：130"),
        input("汽车的重量", name='weight', type=FLOAT,placeholder="例如：3504"),
        input("汽车从0加速到60英里每小时所需的时间", name='acceleration', type=FLOAT,placeholder="例如：12"),
        input("汽车的生产年份", name='model_year', type=FLOAT,placeholder="例如：70"),
        input("汽车的产地，通常用数字表示，如1表示美国，2表示欧洲，3表示日本", name='origin', type=FLOAT,placeholder="例如：1"),
    ])
    
    try:
        # 准备模型输入数据，配合自己设置的输入进行调整
        data = [[inputs['cylinders'], inputs['displacement'], inputs['horsepower'],
                 inputs['weight'], inputs['acceleration'], inputs['model_year'], inputs['origin']]]

        data = scaler.transform(np.array(data).reshape(1, -1))
        
        # 模型推理
        result = baseml.inference(data=data)
        mpg = result[0]
        
        # 输出预测结果
        put_text(f'根据模型预测，你的汽车每加仑燃油可以行驶的英里数大约为：{mpg:.2f}英里每加仑')
    
    except Exception as e:
        put_text(f"发生错误: {e}")

if __name__ == '__main__':
    start_server(main, port=8080)
