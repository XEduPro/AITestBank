import PySimpleGUI as sg
from XEdu.hub import Workflow as wf
from BaseDT.dataset import split_tab_dataset
import numpy as np

# 加载数据集和模型
path = "auto-mpg.csv"
tx, ty, val_x, val_y, scaler = split_tab_dataset(path, data_column=range(0, 7), label_column=7, normalize=True)
baseml = wf(task='baseml', checkpoint='mymodel.pkl')

# 定义GUI布局
layout = [
    [sg.Text("汽车燃油效率预测系统")],
    [sg.Text("汽车发动机的气缸数量（填写示例：8）:"), sg.InputText(key='cylinders')],
    [sg.Text("发动机排量（填写示例：307）:"), sg.InputText(key='displacement')],
    [sg.Text("发动机的输出功率（填写示例：130）:"), sg.InputText(key='horsepower')],
    [sg.Text("汽车的重量（填写示例：3504）:"), sg.InputText(key='weight')],
    [sg.Text("汽车从0加速到60英里每小时所需的时间（填写示例：12）:"), sg.InputText(key='acceleration')],
    [sg.Text("汽车的生产年份（填写示例：72）:"), sg.InputText(key='model_year')],
    [sg.Text("汽车的产地（1表示美国，2表示欧洲，3表示日本）:"), sg.InputText(key='origin')],
    [sg.Button("预测"), sg.Button("退出")],
    [sg.Text("", size=(70, 2), key='output')]
]

# 创建窗口
window = sg.Window("燃油效率预测", layout)

while True:
    event, values = window.read()

    if event in (sg.WIN_CLOSED, "退出"):
        break

    if event == "预测":
        try:
            # 准备模型输入数据
            data = [[float(values['cylinders']), float(values['displacement']), float(values['horsepower']),
                     float(values['weight']), float(values['acceleration']), float(values['model_year']),
                     float(values['origin'])]]

            data = scaler.transform(np.array(data).reshape(1, -1))

            # 模型推理
            result = baseml.inference(data=data)
            mpg = result[0]

            # 输出预测结果
            window['output'].update(f'根据模型预测，你的汽车每加仑燃油可以行驶的英里数大约为：{mpg:.2f}英里每加仑')

        except Exception as e:
            window['output'].update(f"发生错误: {e}")

window.close()
