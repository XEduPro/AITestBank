# 导入库文件，选择回归模块
from BaseML import Regression as reg
# 构建线性回归模型
model = reg(algorithm = 'Polynomial')
# 载入数据集
model.load_tab_data('./auto-mpg_train.csv')
# 训练模型
model.train()
# 读取验证集进行验证并计算R平方值
r2_Poly, result = model.valid('./auto-mpg_val.csv', metrics='r2') # 载入验证数据
model.metricplot() # 可视化验证效果
model.save('mymodel2.pkl')