# coding:utf-8
from BaseML import Regression as reg

def generated_train():
	model = reg('LinearRegression')
	model.load_tab_data(r'D:\XEdu\datasets\basenn\auto-mpg\auto-mpg_train.csv', random_seed=666)
	model.train()
	model.save(r'D:\XEdu\my_checkpoints\baseml_20240529_234129/reg.pkl')
	model.valid(r'D:\XEdu\datasets\basenn\auto-mpg\auto-mpg_val.csv',metrics='')

if __name__ == '__main__':
	generated_train()