# 第二题
# 方法1：直接图片分类，效果稍差且速度慢


# In[1]:


from MMEdu import MMClassification as cls
model = cls('LeNet')
model.num_classes = 3
model.load_dataset(path='wqx3_imagenet')
model.save_fold = 'wqx1'          # 模型将保存在XEdu示例代码下的my_models内
log=model.train(epochs=10, validate=True) # 从零开始训练中不指定checkpoint参数


# In[ ]:


from MMEdu import MMClassification as cls
model = cls('ResNet18')
model.num_classes = 3
model.load_dataset(path='wqx3_imagenet',check=False)
model.save_fold = 'wqx1'          # 模型将保存在XEdu示例代码下的my_models内
log=model.train(epochs=10, validate=True,checkpoint='../checkpoints/mmedu_cls_model/ImageNet-1k/resnet18_1k_pretrain.pth') # 从零开始训练中不指定checkpoint参数


# In[ ]:

# 写一个界面实时预测
from XEdu.hub import Workflow as wf
import cv2
det = wf(task='det_body')
mmcls = wf(task='mmedu',checkpoint='mmedu.onnx')# 指定使用的onnx模型     # 指定模型
cap = cv2.VideoCapture(0)       # 打开摄像头

while cap.isOpened():
    ret, frame = cap.read()      # 获取摄像头画面保存在frame中
    if not ret:
        break
    bboxs, new_img = det.inference(data=frame, img_type='cv2') # 目标检测推理
    if len(bboxs)>0:            # 有人
        result,img = mmcls.inference(data=new_img,img_type='cv2')# 进行模型推理
        format_result = mmcls.format_output(lang='zh')
        new_img = cv2.putText(new_img, str(format_result['预测结果']), (200, 100), cv2.FONT_HERSHEY_COMPLEX, 2.0, (100, 200, 200), 5)
    else:                      # 没有人
        new_img = cv2.putText(new_img, "noperson", (200, 100), cv2.FONT_HERSHEY_COMPLEX, 2.0, (100, 200, 200), 5)  
    cv2.imshow('video', new_img)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break    
cap.release()
cv2.destroyAllWindows()



# In[ ]:


# 方法二：使用关键点提取，先提取特征


# In[ ]:


# 第一步：提取所有图片的关键点信息，制作关键点数据集


# In[2]:


import os
import numpy as np
from XEdu.hub import Workflow as wf
body = wf(task='pose_body17')# 实例化pose模型
det = wf(task='det_body')# 实例化detect模型
ds = os.listdir('wqx3_imagenet/training_set')
for d in ds:
    if d[0]=='c':
        continue
    fs = os.listdir(os.path.join('wqx3_imagenet/training_set',d))
    for f in fs:
        path = os.path.join('wqx3_imagenet/training_set',d,f)
        print(path)
        bboxs = det.inference(data=path,thr=0.3)
        if len(bboxs)>0:
            for i in bboxs:
                keypoints = body.inference(data=path,bbox=i)
                array = np.array(keypoints).reshape(1,-1)
                #print(array)
                x_min = array.min()
                x_max = array.max()
                normalized_arr = (array - x_min) / (x_max - x_min) # 做一个归一化
                # 打开文件，如果文件不存在则创建，并追加内容
                with open('train2.csv', 'a') as file:
                    #file.write(d[0])
                    for n in normalized_arr[0]:
                        file.write(str(n)+',')
                    file.write(d[0]+'\n')
                #print(keypoints)
        else:
            pass


# In[ ]:


# 第二步：搭建神经网络训练模型，并保存


# In[4]:


from BaseNN import nn
model = nn('cls')
train_path = 'train3.csv'
model.load_tab_data(train_path, batch_size=1000)
model.add(layer='linear',size=(34, 64),activation='relu') # [120, 10]
model.add(layer='linear',size=(64, 8), activation='relu') # [120, 5]
model.add(layer='linear', size=(8, 3), activation='softmax') # [120, 3]
model.save_fold = 'checkpoints/iris_ckpt'
# 模型训练
model.train(lr=0.01, epochs=1000)


# In[ ]:


# 验证模型效果，同样要提取验证集关键点


# In[5]:


import os
import numpy as np
from XEdu.hub import Workflow as wf
body = wf(task='pose_body17')# 实例化pose模型
det = wf(task='det_body')# 实例化detect模型
ds = os.listdir('wqx3_imagenet/val_set')
for d in ds:
    if d[0]=='c':
        continue
    fs = os.listdir(os.path.join('wqx3_imagenet/val_set',d))
    for f in fs:
        path = os.path.join('wqx3_imagenet/val_set',d,f)
        print(path)
        bboxs = det.inference(data=path,thr=0.3)
        if len(bboxs)>0:
            for i in bboxs:
                keypoints = body.inference(data=path,bbox=i)
                array = np.array(keypoints).reshape(1,-1)
                #print(array)
                x_min = array.min()
                x_max = array.max()
                normalized_arr = (array - x_min) / (x_max - x_min) # 用一样的归一化方法
                # 打开文件，如果文件不存在则创建，并追加内容
                with open('val.csv', 'a') as file:
                    #file.write(d[0])
                    for n in normalized_arr[0]:
                        file.write(str(n)+',')
                    file.write(d[0]+'\n')
                #print(keypoints)
        else:
            pass


# In[9]:


import numpy as np
# 读取验证集
val_path = 'val.csv'
val_x = np.loadtxt(val_path, dtype=float, delimiter=',',skiprows=1,usecols=range(0,34)) # 读取特征列
val_y = np.loadtxt(val_path, dtype=float, delimiter=',',skiprows=1,usecols=34) # 读取预测值列

# 导入库
from BaseNN import nn
# 声明模型
model = nn('reg') 
y_pred = model.inference(val_x,checkpoint = 'basenn.pth')  # 对该数据进行预测


# In[12]:


# 用测试数据查看模型效果
model2 = nn('cls')
test_path = 'val.csv'
test_x = np.loadtxt(test_path, dtype=float, delimiter=',',skiprows=1,usecols=range(0,34)) 
# 获取最后一列的真实值
test_y = np.loadtxt(test_path, dtype=float, delimiter=',',skiprows=1,usecols=34) 

res = model2.inference(test_x, checkpoint="basenn.pth")
model2.print_result(res)

# 定义一个计算分类正确率的函数
def cal_accuracy(y, pred_y):
    res = pred_y.argmax(axis=1)
    tp = np.array(y)==np.array(res)
    acc = np.sum(tp)/ y.shape[0]
    return acc

# 计算分类正确率
print("分类正确率为：",cal_accuracy(test_y, res))


# In[1]:


# 模型转化
from BaseNN import nn
model = nn()
model.convert(checkpoint="checkpoints/iris_ckpt/basenn.pth",out_file="basenn.onnx")


# In[ ]:


# 写一个界面实时预测
import cv2
import numpy as np
from XEdu.hub import Workflow as wf
body = wf(task='pose_body17')# 实例化pose模型
det = wf(task='det_body')# 实例化detect模型
classes = ['2_deerbutt','4_bearswing','6_monkeylift']

model = wf(task='basenn',checkpoint='basenn.onnx')
cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    bboxs = det.inference(data=frame,thr=0.3)
    if len(bboxs)>0:
        for i in bboxs:
            keypoints = body.inference(data=frame,bbox=i)
            array = np.array(keypoints).reshape(1,-1)
            x_min = array.min()
            x_max = array.max()
            normalized_arr = (array - x_min) / (x_max - x_min) # 用一样的归一化方法
            res = model.inference(normalized_arr)
            #print(res)
            res = model.format_output(isprint=False)
            print(classes[res[0]['预测值']])
            
    cv2.putText(frame, classes[res[0]['预测值']], (100, 200), cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 255, 0), 2)
    cv2.imshow("Camera", frame)
    # 按下 'q' 键退出循环
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# 关闭摄像头和窗口
cap.release()
cv2.destroyAllWindows()


# In[ ]:




